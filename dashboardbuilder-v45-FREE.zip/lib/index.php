<?php session_start();
$folder ="..".DIRECTORY_SEPARATOR;
include('top.php');

if (isset($_POST['takeatourtask'])) {
		if ($_POST["takeatourtask"]=='submit'){
			if (isset($_POST['takeatour_checkbox'])) {
			     takeatoursubmit($_POST['takeatour_checkbox']);
			} else {
				takeatoursubmit("");
			}
		}
}


$param = '';
$able = 'class="disabled"'. '  style="color:#CCCCCC;"';
if (isset($_REQUEST['col'])){
if (!empty($_REQUEST['col'])){
		 $param = 'col='.$_REQUEST['col'].'&p=1';
		 $able = '';
	}
}



if (isset($_POST['loadsampledata'])) {
	$file = $folder.'store'.DIRECTORY_SEPARATOR.'sampledata.data';
			$newfile = $folder.'data'.DIRECTORY_SEPARATOR.'data.xml';
			
			if (!copy($file, $newfile)) {
				echo '<div class="alert alert-danger alert-dismissable col-md-4 col-md-offset-4">
										<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
										<strong>Error! failed to copy </strong> '.$file.
										'<br/><br/><div>Please make sure!</div>
										<ul>
										<li>allow_url_fopen is enabled</li>
										<li>Read-Write permission to folders and sub-folders of dashboardbuilder i.e chmod -R 777 dashbboardbuilder-v?-FREE</li>
                                        </ul>
										<br/>
										<div>For more details take a look at the <a href="https://dashboardbuilder.net/documentation" target="_blank">User Guide</a></div>
									  </div>';
			}
			
			$file = $folder.'store'.DIRECTORY_SEPARATOR.'sampledata.lay';
			$newfile = $folder.'data'.DIRECTORY_SEPARATOR.'layout.xml';
			$_SESSION['filename']= "sampledata";
			if (!copy($file, $newfile)) {
				echo _TEXT['ERROR_COPY'].$file."\n";
			}
			
}
?>
<style>
.disabled {
   pointer-events: none;
   cursor: default;
}
</style>
							
<div class="container-fluid main-container">

 <div class="col-md-12 content" >
  <div>

<div >
		
<div class="row">

<!-- Modal -->
<div class="modal fade" id="youtube" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-body">
      
        <iframe id="iframeYoutube" width="560" height="315"  frameborder="0" allowfullscreen></iframe> 
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo _TEXT['CLOSE'];?></button>
      </div>
    </div>
  </div>
</div>
<ol class="breadcrumb">
	
		<a href="javascript:void(0);" class="btn btn-warning" id="file-new" onclick="submitAll('n');">
			<?php echo _TEXT['NEW'];?> <i class="fa fa-file-o"></i>;
		</a>
	
		<a href="javascript:void(0);" class="btn btn-warning" id="file-open" onclick="submitAll('o');" >
			<?php echo _TEXT['OPEN'];?> <i class="fa fa-folder-open-o"></i>
		</a>
		<a href="javascript:void(0);" class="btn btn-warning" id="file-save" onclick="submitAll('3');" >
			<?php echo _TEXT['SAVE'];?> <i class="fa fa-save"></i>
		</a>
		
		

	
		<a href="javascript:void(0);" class="btn btn-warning addpanel" id="addpanelid" >
			<?php echo _TEXT['ADD_PANEL'];?> <i class="fa fa-square-o"><sup><i class="fa fa-plus"></i></sup></i>
		</a>

		<a href="javascript:void(0);" class="btn btn-warning" id="file-generate" onclick="submitAll('g');">
			<?php echo _TEXT['GENERATE'];?> <i class="fa fa-code"></i>
		</a>
		
		<a href="javascript:void(0);" class="btn btn-warning" id="file-share" onclick="submitAll('s');">
			<?php echo _TEXT['SHARE'];?> <i class="fa fa-share-alt"></i>
		</a>
		
		<a href="javascript:void(0);" class="btn btn-warning" id="preview" onclick="preview();">
			<?php echo _TEXT['PREVIEW'];?> <i class="fa fa-eye"></i>
		</a>
		
		
		<!--- After Privew --->
		<a href="javascript:void(0);" class="btn btn-warning" id="print" onclick="print();" style="display:none;">
			<?php echo _TEXT['PRINT'];?> <i class="fa fa-print"></i>
		</a>
		<a href="javascript:void(0);" class="btn btn-warning" id="export_image" onclick="export_image();" style="display:none;">
			<?php echo _TEXT['EXPORT_IMAGE'];?> <i class="fa fa-picture-o"></i>
		</a>
		
		<a href="javascript:void(0);" class="btn btn-default" id="close_preview" onclick="close_preview();" style="display:none;">
			<?php echo _TEXT['CLOSE'];?> <i class="fa fa-close"></i>
		</a>
		
		
		

	<li>
		<i class="fa fa-th" > </i> <span id="savefilename"><?php echo _TEXT['FILE'];?>: <?php if(isset($_SESSION['filename'])) {echo $_SESSION['filename']; } else { echo _TEXT['UNTITLE'];}?></span>
	</li>
	
	<li id="panelno"><?php echo _TEXT['PANEL'];?> 1</li>
	<li id="resize"><?php echo _TEXT['SIZE'];?>:</li> 
	<li id="reposition"><?php echo _TEXT['POSITION'];?>:</li>
	
						<span style="float:right;">
						&nbsp;&nbsp;
						<a href="#" onclick="$('#takeatour').modal({backdrop: 'static', keyboard: false});"><button class="btn btn-danger" ><?php echo _TEXT['TAKE_A_TOUR'];?></button></a>
						</span>
						
						<span style="float:right;">
						<form action="" method="post"  ><input type="hidden" name="loadsampledata" value="loadsampledata"><button class="btn btn-success" ><?php echo _TEXT['SAMPLE_DATA'];?></button></form>

						</span>

	
</ol>

<div id="details">
<?php 
for ($x = 1; $x <= 12; $x++) { ?>
<div class="col-md-1 col-xs-1 col-lg-1" style="padding:0;"><div id="grids" style="text-align:center;"><mylabel>col-<?php echo $x;?></mylabel></div></div>
<?php } ?>

<!-- Modal take a tour-->
<div class="modal fade in" id="takeatour" tabindex="-1" role="dialog" aria-labelledby="myModalLabe9" >
  <div class="modal-dialog modal-md" role="document" style="width:60% !important;">
    <div class="modal-content">
	<?php include ('takeatour.php');?>
    </div>
  </div>
</div>

<!-- Modal take a tour End -->

<?php 
$xml=simplexml_load_file($folder."data/data.xml") or die("Error: Cannot create object");
$layout=simplexml_load_file($folder."data/layout.xml") or die("Error: Cannot create object");
include ('layout.php');?>
<?php include ('col.php');?>
<!-- Modal -->
</div>

</div>



<?php
function takeatoursubmit($takeatour_checkbox) {
	
	$xmlinfoFile = '../data/version.xml';
	$xmlinfo=simplexml_load_file($xmlinfoFile);
	if (empty($xmlinfo->date)) {
		$xmlinfo->date=date("Ymd");
	}
	
	if ($_POST['languagechange']=='yes') {
		$xmlinfo->language=$_POST['take_tour_language'];
		$_SESSION['tower_showed']="";
		$xmlinfo->takeatour="true";
	} else {
		$_SESSION['tower_showed']="yes";
		$xmlinfo->takeatour="false";
	}
	
	$xmlinfo->asXML($xmlinfoFile);	
	
	
	/*
	$_SESSION['tower_showed']="yes";
	$xmlinfoFile = '../data/version.xml';
	$xmlinfo=simplexml_load_file($xmlinfoFile);
	$xmlinfo->takeatour="false";
	if (empty($xmlinfo->date)) {
		$xmlinfo->date=date("Ymd");
	}
	$xmlinfo->asXML($xmlinfoFile);
	*/
}
echo '
<script>
function changeVideo(vId){
	
  $("#youtube").on("hidden.bs.modal",function(){
    $("#iframeYoutube").attr("src","#");
  })
	
  var iframe=document.getElementById("iframeYoutube");
  iframe.src="https://www.youtube.com/embed/"+vId;

  $("#youtube").modal("show");
}';

if ($xmlinfo->takeatour=="true") {
	if (empty($_SESSION['tower_showed'])) {
		echo "$(window).on('load',function(){
			$('#takeatour').modal({backdrop: 'static', keyboard: false});
  
		});";
		
	}
}
?>
$( '.main-container' ).click(function(e) {
document.getElementById("dropdown-menu").style.display = "none";
});


<?php
echo '</script>';
include ('bottom.php');?>
